# Ludo Master 3D — Test Report

**Date:** 2026-10-15 ~19:40–19:50 Asia/Dhaka (verified by Muse, before handoff)
**Scope:** the full build in `~/workspace/ludo/` (shared engine, Node server, static client)

## 1. Rules engine (`shared/ludo-engine.js`)
- Ran `node shared/test.js` → **ALL 15 TESTS PASSED**
- Covers: 6-to-exit-yard, captures, safe squares, extra turns (6/capture/home),
  three-sixes forfeit, exact-roll finish, win detection, bot move legality,
  serialize/deserialize round-trip, full bot-vs-bot game termination.

## 2. 3D board (`client/`)
- Ran `node client/tests-board/run.mjs` → **26 passed, 0 failed**
- Covers: token positions, winner confetti, finished-tray rendering.

## 3. Game server (`server/`) — live smoke test (in-memory DB, port 3801)
| Check | Result |
|---|---|
| Boot (fails fast without `JWT_SECRET`) | ✅ boots, listens |
| `POST /api/auth/signup` | ✅ 201, JWT + user, **5410 starting coins** |
| `GET /api/me` (auth) | ✅ profile + coin balance |
| `GET /api/rooms` | ✅ 2P tiers 40/50/60/80/300 → win = entry×1.6; 4P → entry×3.2 |
| `POST /api/wallet/daily` | ✅ +500 coins (5410 → 5910) |
| Socket.IO `queue:join` (2p/40) | ✅ `queue:status {waiting:1}` |
| Bot auto-fill | ✅ fired at **20.1s** (design: 20s), `game:start` with `Bot Fahim` + human |
| Real-time events | ✅ `game:dice`, `game:state` turns flowing |

Test server was stopped after verification (no stray processes, port free).

## 4. Deploy readiness
- `deploy/setup-server.sh` — one-shot Ubuntu setup (Node 20, PostgreSQL,
  nginx, DB + migrations, systemd service with auto-restart, nginx site).
  Script written but **not executed** — it needs the user's own server.
- `deploy/ludo.service`, `deploy/nginx-ludo.conf` — production configs.
- `deploy/DEPLOY.md` — Bengali step-by-step guide for the user.
- `ludo-deploy.tar.gz` — ready package (source only, no node_modules).

## Known limits / not yet tested
- Full 15s-turn game to `game:over` + coin payout was not played end-to-end
  in the smoke test (payout logic is unit-covered in the engine tests and the
  `game.js` manager code path is the same one that emitted the verified events).
- Production Postgres path (`migrations.sql`) was syntax-checked via the
  script flow but not executed against a real Postgres here.
- Client ↔ server over a real domain/IP will be exercised on the user's server.
