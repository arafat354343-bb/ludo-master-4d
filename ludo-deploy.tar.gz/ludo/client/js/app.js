/* Ludo Master 3D — app shell: hash router, screens, modals, game-flow glue.
 * ---------------------------------------------------------------------------
 * 3D BOARD INTEGRATION CONTRACT (implemented by a teammate):
 *   window.LudoBoard = {
 *     init(containerEl) : Promise,          // mount the 3D board once
 *     setState(pubState, myColor),           // render authoritative state
 *     animateDice(value) : Promise,          // play dice roll animation
 *     onUserRoll: null | fn,                 // board calls it when its own dice UI is tapped
 *     onTokenPick: null | fn,                // board calls it with token index 0..3
 *     showWinner(color)                      // celebration for the winning color
 *   }
 * Every LudoBoard call below is guarded with `hasBoard()` so this UI works
 * before the board module lands (a minimal 2D fallback covers dice + moves).
 * ---------------------------------------------------------------------------
 * SERVER INTEGRATION POINTS expected by this file:
 *   REST (js/api.js): POST /api/auth/signup {name,email,password} -> {token,user}
 *                     POST /api/auth/login {email,password}        -> {token,user}
 *                     GET  /api/me                                 -> user | {user}
 *                     PUT  /api/me {name}                          -> user
 *                     GET  /api/stats                              -> {gamesPlayed,gamesWon,winRate,totalEarned,coins,wins2p,wins4p}
 *                     GET  /api/rooms                              -> [{mode:'2p'|'4p',entry,win,online}]
 *                     POST /api/wallet/daily                       -> {amount|coins|bonus}
 *   SOCKET (js/socket.js): see the wire contract comment at its top.
 * ------------------------------------------------------------------------ */
(function () {
'use strict';

/* ---------------- helpers ---------------- */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const TOKEN_KEY = 'ludo_token';
const USER_KEY = 'ludo_user';

function esc(v) {
  return String(v === undefined || v === null ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fmt(n) {
  n = Number(n);
  return Number.isFinite(n) ? n.toLocaleString('en-US') : '0';
}

let toastTimer = null;
function toast(msg, ms) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), ms || 2200);
}

function openModal(sel) { $(sel).classList.add('open'); }
function closeModal(sel) { $(sel).classList.remove('open'); }
function closeAllModals() { $$('.modal-overlay.open').forEach((m) => m.classList.remove('open')); }

/* ---------------- store ---------------- */
const store = {
  get token() { return localStorage.getItem(TOKEN_KEY); },
  set token(v) { v ? localStorage.setItem(TOKEN_KEY, v) : localStorage.removeItem(TOKEN_KEY); },
  get user() { try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch (e) { return null; } },
  set user(u) { u ? localStorage.setItem(USER_KEY, JSON.stringify(u)) : localStorage.removeItem(USER_KEY); }
};

function coinsOf(u) {
  if (!u) return 0;
  const v = u.coins !== undefined ? u.coins : (u.balance !== undefined ? u.balance : u.money);
  return Number(v) || 0;
}
function avatarLetter(name) {
  name = (name || '').trim();
  return name ? name[0].toUpperCase() : '?';
}

/* ---------------- router ---------------- */
const SCREENS = ['splash', 'auth', 'home', 'rooms', 'game', 'dashboard'];
const ENTER = {};

function parseHash() {
  const h = (location.hash || '#/splash').replace(/^#\/?/, '');
  const qi = h.indexOf('?');
  return {
    name: qi < 0 ? h : h.slice(0, qi),
    query: new URLSearchParams(qi < 0 ? '' : h.slice(qi + 1))
  };
}

function show(name) {
  SCREENS.forEach((s) => $('#screen-' + s).classList.toggle('active', s === name));
  window.scrollTo(0, 0);
}

function navigate() {
  const parsed = parseHash();
  const target = SCREENS.indexOf(parsed.name) >= 0 ? parsed.name : 'home';
  const authed = !!store.token;
  if (!authed && (target === 'home' || target === 'rooms' || target === 'game' || target === 'dashboard')) {
    if (location.hash !== '#/auth') location.hash = '#/auth';
    return;
  }
  if (target === 'game' && !G.state) {
    if (location.hash !== '#/home') location.hash = '#/home';
    return;
  }
  closeAllModals();
  show(target);
  if (ENTER[target]) {
    try { ENTER[target](parsed.query); } catch (e) { console.error('[app]', e); }
  }
}
window.addEventListener('hashchange', navigate);

/* ---------------- socket wiring ---------------- */
let socketWired = false;
function ensureSocket() {
  if (!store.token) return;
  Socket.connect(store.token);
  if (socketWired) return;
  socketWired = true;

  Socket.on('queue:update', (d) => {
    if (d && typeof d.waiting === 'number') $('#waiting-count').textContent = d.waiting;
  });
  Socket.on('game:start', (state) => {
    closeModal('#overlay-waiting');
    G.myColor = null;
    G.state = state;
    if ((location.hash || '').indexOf('#/game') === 0) { ENTER.game(); }
    else { location.hash = '#/game'; }
  });
  Socket.on('game:state', (state) => { applyState(state); });
  Socket.on('game:dice', onDiceRolled);
  Socket.on('game:over', onGameOver);
  Socket.on('error', (d) => { toast((d && d.message) || 'Server error'); });
}

/* ---------------- game glue ---------------- */
const COLOR_HEX = { red: '#e63946', green: '#2fbf71', yellow: '#f4b400', blue: '#3b82f6' };
const G = {
  state: null,
  myColor: null,
  boardReady: false,
  rolling: false,
  timerId: null
};

function hasBoard() {
  return typeof window.LudoBoard !== 'undefined' && !!window.LudoBoard;
}

function myPlayerId() {
  const u = store.user;
  return u ? (u.id || u._id || u.userId || null) : null;
}

function myColorFrom(state) {
  if (!state || !Array.isArray(state.players)) return null;
  const pid = myPlayerId();
  let p = null;
  if (pid !== null && pid !== undefined) {
    p = state.players.find((x) => !x.isBot && String(x.id) === String(pid)) || null;
  }
  if (!p) p = state.players.find((x) => !x.isBot) || state.players[0] || null;
  return p ? p.color : null;
}

async function ensureBoard() {
  const B = hasBoard();
  if (!B) return false;
  if (!G.boardReady) {
    try {
      await B.init($('#board-container'));
      G.boardReady = true;
    } catch (e) {
      console.error('[app] LudoBoard.init failed:', e);
      return false;
    }
  }
  return true;
}

function isMyTurn(state) {
  return !!state && state.turnColor === G.myColor;
}

async function applyState(state) {
  if (!state) return;
  G.state = state;
  if (!G.myColor) G.myColor = myColorFrom(state);
  renderHud();
  const B = hasBoard();
  if (B) {
    const ok = await ensureBoard();
    if (ok) {
      try { B.onUserRoll = doRoll; } catch (e) {}
      try { B.setState(state, G.myColor); } catch (e) { console.error('[app] setState failed:', e); }
    }
  }
  resetTimer();
  updateDiceButton();
  maybePromptMove();
}

function renderHud() {
  const s = G.state;
  if (!s) return;
  $('#hud-mode').textContent = s.mode === '4p' ? '4 Players' : '2 Players';
  $('#hud-entry').textContent = fmt(s.entry);

  const chips = $('#chips');
  chips.innerHTML = '';
  (s.players || []).forEach((p) => {
    const el = document.createElement('div');
    el.className = 'chip' + (p.color === s.turnColor ? ' active' : '') + (p.color === G.myColor ? ' me' : '');
    const label = p.color === G.myColor ? 'You' : (p.name || p.color);
    const fin = p.finishedCount !== undefined ? p.finishedCount
      : (Array.isArray(p.tokens) ? p.tokens.filter((t) => t === 57).length : 0);
    el.innerHTML =
      '<span class="cdot" style="background:' + (COLOR_HEX[p.color] || '#999') + '"></span>' +
      '<span class="cname">' + esc(label) + '</span>' +
      '<span class="cstar">★ ' + fin + '/4</span>';
    chips.appendChild(el);
  });

  // 2D fallback: show movable token buttons when the 3D board is absent.
  const fb = $('#move-fallback');
  fb.innerHTML = '';
  if (!hasBoard() && s.phase === 'awaitingMove' && isMyTurn(s) && Array.isArray(s.movableTokens)) {
    fb.classList.remove('hidden');
    s.movableTokens.forEach((i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = 'Token ' + (i + 1);
      b.addEventListener('click', () => doMove(i));
      fb.appendChild(b);
    });
  } else {
    fb.classList.add('hidden');
  }
}

function resetTimer() {
  clearInterval(G.timerId);
  const fill = $('#timer-fill');
  const text = $('#timer-text');
  if (!fill || !text) return;
  const secs = CONFIG.TURN_SECONDS || 15;
  let left = secs;
  text.textContent = left + 's';
  fill.style.transition = 'none';
  fill.style.width = '100%';
  // force reflow so the transition restarts
  void fill.offsetWidth;
  fill.style.transition = 'width ' + secs + 's linear';
  fill.style.width = '0%';
  G.timerId = setInterval(() => {
    left -= 1;
    if (left <= 0) { left = 0; clearInterval(G.timerId); }
    text.textContent = left + 's';
  }, 1000);
}

function updateDiceButton() {
  const btn = $('#dice-btn');
  const s = G.state;
  const canRoll = !!s && s.phase === 'awaitingRoll' && isMyTurn(s) && !G.rolling;
  btn.disabled = !canRoll;
  btn.classList.toggle('ready', canRoll);
}

async function doRoll() {
  const s = G.state;
  if (G.rolling || !s || s.phase !== 'awaitingRoll' || !isMyTurn(s)) return;
  G.rolling = true;
  updateDiceButton();
  hideHint();
  Socket.rollDice();
}

function doMove(i) {
  const s = G.state;
  if (!s || s.phase !== 'awaitingMove' || !isMyTurn(s)) return;
  hideHint();
  const B = hasBoard();
  if (B) { try { B.onTokenPick = null; } catch (e) {} }
  Socket.sendMove(i);
}

function maybePromptMove() {
  const s = G.state;
  const B = hasBoard();
  if (s && s.phase === 'awaitingMove' && isMyTurn(s)) {
    showHint('Your move — tap a glowing token');
    if (B && Array.isArray(s.movableTokens) && s.movableTokens.length) {
      try {
        B.onTokenPick = (i) => { doMove(i); };
      } catch (e) {}
    }
  } else {
    hideHint();
    if (B) { try { B.onTokenPick = null; } catch (e) {} }
  }
}

async function onDiceRolled(d) {
  G.rolling = false;
  const B = hasBoard();
  if (B && typeof B.animateDice === 'function') {
    try { await B.animateDice(d && d.value); } catch (e) { console.error('[app] animateDice failed:', e); }
  } else {
    flashDiceValue(d && d.value);
  }
  updateDiceButton();
}

function flashDiceValue(v) {
  const btn = $('#dice-btn');
  if (v) {
    btn.style.transform = 'scale(1.12)';
    setTimeout(() => { btn.style.transform = ''; }, 220);
  }
  showHint(v ? 'Rolled ' + v : '');
  setTimeout(hideHint, 1200);
}

function showHint(msg) {
  const h = $('#hud-hint');
  h.textContent = msg;
  h.classList.remove('hidden');
}
function hideHint() { $('#hud-hint').classList.add('hidden'); }

function onGameOver(d) {
  d = d || {};
  clearInterval(G.timerId);
  const B = hasBoard();
  if (B && typeof B.showWinner === 'function') {
    try { B.showWinner(d.winner); } catch (e) {}
  }
  const won = d.isWinner !== undefined ? !!d.isWinner : (d.winner === G.myColor);
  const delta = Number(d.delta !== undefined ? d.delta : (d.coins !== undefined ? d.coins : 0)) || 0;
  $('#go-title').textContent = won ? 'You Win!' : 'Game Over';
  $('#go-winner').textContent = 'Winner: ' + (d.winnerName || d.winner || '—');
  const gd = $('#go-delta');
  if (won) {
    gd.textContent = 'You won +' + fmt(delta) + ' coins';
    gd.classList.add('win');
  } else {
    gd.textContent = 'Better luck next time' + (delta ? ' (' + (delta > 0 ? '+' : '') + fmt(delta) + ' coins)' : '');
    gd.classList.remove('win');
  }
  openModal('#modal-gameover');
  refreshMe();
}

function leaveGame() {
  clearInterval(G.timerId);
  try { Socket.leaveQueue(); } catch (e) {}
  G.state = null;
  G.myColor = null;
  G.rolling = false;
  hideHint();
  location.hash = '#/home';
}

/* ---------------- splash ---------------- */
ENTER.splash = () => {
  setTimeout(() => {
    location.hash = store.token ? '#/home' : '#/auth';
  }, 1200);
};

/* ---------------- auth ---------------- */
function setTab(which) {
  $('#tab-login').classList.toggle('active', which === 'login');
  $('#tab-signup').classList.toggle('active', which === 'signup');
  $('#form-login').classList.toggle('hidden', which !== 'login');
  $('#form-signup').classList.toggle('hidden', which !== 'signup');
}
function emailOk(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }

async function handleAuthSuccess(data) {
  const token = data && (data.token || data.accessToken);
  if (!token) throw new Error('Server did not return a token.');
  store.token = token;
  let user = data.user || data.player || null;
  if (!user) {
    try { const me = await Api.me(); user = me.user || me; } catch (e) {}
  }
  if (user) store.user = user;
  ensureSocket();
  location.hash = '#/home';
}

ENTER.auth = () => {
  if (store.token) { location.hash = '#/home'; return; }
  setTab('login');
};

function bindAuth() {
  $('#tab-login').addEventListener('click', () => setTab('login'));
  $('#tab-signup').addEventListener('click', () => setTab('signup'));

  $('#form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = $('#login-email').value.trim();
    const pw = $('#login-password').value;
    const err = $('#login-err');
    if (!emailOk(email)) { err.textContent = 'Enter a valid email address.'; return; }
    if (!pw) { err.textContent = 'Enter your password.'; return; }
    err.textContent = '';
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    try {
      await handleAuthSuccess(await Api.login(email, pw));
    } catch (ex) { err.textContent = ex.message; }
    btn.disabled = false;
  });

  $('#form-signup').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = $('#signup-name').value.trim();
    const email = $('#signup-email').value.trim();
    const pw = $('#signup-password').value;
    const err = $('#signup-err');
    if (name.length < 2) { err.textContent = 'Name must be at least 2 characters.'; return; }
    if (!emailOk(email)) { err.textContent = 'Enter a valid email address.'; return; }
    if (pw.length < 6) { err.textContent = 'Password must be at least 6 characters.'; return; }
    err.textContent = '';
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    try {
      await handleAuthSuccess(await Api.signup(name, email, pw));
    } catch (ex) { err.textContent = ex.message; }
    btn.disabled = false;
  });
}

/* ---------------- home ---------------- */
function renderHeader() {
  const u = store.user || {};
  const name = u.name || 'Player';
  $('#home-name').textContent = name;
  $('#home-avatar').textContent = avatarLetter(name);
  $('#home-balance').textContent = fmt(coinsOf(u));
}

async function refreshMe() {
  try {
    const me = await Api.me();
    const user = me.user || me;
    if (user && (user.id || user._id || user.email || user.name)) {
      store.user = user;
      renderHeader();
    }
  } catch (e) { /* offline or expired — api.js already redirects on 401 */ }
}

async function loadOnlineCounts() {
  const el2 = $('#online-2p');
  const el4 = $('#online-4p');
  try {
    const res = await Api.rooms();
    const arr = Array.isArray(res) ? res : (res.rooms || []);
    let n2 = 0, n4 = 0, seen2 = false, seen4 = false;
    arr.forEach((r) => {
      const n = Number(r.online) || 0;
      if ((r.mode || '2p') === '2p') { n2 += n; seen2 = true; }
      else { n4 += n; seen4 = true; }
    });
    el2.textContent = 'Online Player - ' + (seen2 ? fmt(n2) : '—');
    el4.textContent = 'Online Player - ' + (seen4 ? fmt(n4) : '—');
  } catch (e) {
    el2.textContent = 'Online Player - —';
    el4.textContent = 'Online Player - —';
  }
}

ENTER.home = () => {
  ensureSocket();
  renderHeader();
  refreshMe();
  loadOnlineCounts();
};

function bindHome() {
  $('#mode-2p').addEventListener('click', () => { location.hash = '#/rooms?mode=2p'; });
  $('#mode-4p').addEventListener('click', () => { location.hash = '#/rooms?mode=4p'; });
  const openProfile = () => openProfileModal();
  $('#avatar-btn').addEventListener('click', openProfile);
  $('#avatar-btn').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openProfile(); }
  });
  const openCoins = () => openCoinModal();
  $('#coin-plus').addEventListener('click', (e) => { e.stopPropagation(); openCoins(); });
  $('#buy-coin-btn').addEventListener('click', openCoins);
  $('#nav-wallet').addEventListener('click', openCoins);
  $('#nav-trophy').addEventListener('click', () => { location.hash = '#/dashboard'; });
}

/* ---------------- rooms ---------------- */
function roomModeLabel(mode) { return mode === '4p' ? '1 vs 1 vs 1 vs 1' : '1 vs 1'; }

ENTER.rooms = async (query) => {
  const mode = query.get('mode') === '4p' ? '4p' : '2p';
  $('#rooms-title').textContent = mode === '4p' ? 'Four Players' : 'Two Players';
  const list = $('#rooms-list');
  list.innerHTML = '<div class="loading">Loading rooms…</div>';
  ensureSocket();
  try {
    const res = await Api.rooms();
    const arr = Array.isArray(res) ? res : (res.rooms || []);
    const mine = arr.filter((r) => (r.mode || '2p') === mode);
    renderRooms(mine, mode);
  } catch (e) {
    list.innerHTML = '<div class="error-box">Could not load rooms.<br>' + esc(e.message) + '</div>';
  }
};

function renderRooms(rooms, mode) {
  const list = $('#rooms-list');
  if (!rooms.length) {
    list.innerHTML = '<div class="loading">No rooms available right now.</div>';
    return;
  }
  list.innerHTML = '';
  rooms.forEach((r) => {
    const entry = Number(r.entry) || 0;
    const win = Number(r.win) || Math.round(entry * (mode === '4p' ? 3.2 : 1.6));
    const card = document.createElement('div');
    card.className = 'room-card';
    card.innerHTML =
      '<div class="room-badge">' + esc(roomModeLabel(mode)) + '</div>' +
      '<div class="room-amounts"><span>Entry : <b>' + fmt(entry) + '</b></span>' +
      '<span>Win : <b>' + fmt(win) + '</b></span></div>';
    const btn = document.createElement('button');
    btn.className = 'btn-gold';
    btn.type = 'button';
    btn.textContent = 'Join';
    btn.addEventListener('click', () => joinRoom(mode, entry));
    card.appendChild(btn);
    list.appendChild(card);
  });
}

function joinRoom(mode, entry) {
  ensureSocket();
  if (!Socket.isConnected()) {
    toast('Connecting to server…');
    Socket.connect(store.token);
  }
  Socket.joinQueue(mode, entry);
  $('#waiting-sub').textContent = (mode === '4p' ? '4 Players' : '2 Players') + ' · Entry ' + fmt(entry);
  $('#waiting-count').textContent = '1';
  openModal('#overlay-waiting');
}

function bindRooms() {
  $('#rooms-close').addEventListener('click', () => { location.hash = '#/home'; });
  $('#waiting-cancel').addEventListener('click', () => {
    try { Socket.leaveQueue(); } catch (e) {}
    closeModal('#overlay-waiting');
  });
}

/* ---------------- game screen ---------------- */
ENTER.game = async () => {
  if (!G.state) { location.hash = '#/home'; return; }
  const B = hasBoard();
  if (B) {
    await ensureBoard();
    try { B.onUserRoll = doRoll; B.onTokenPick = null; } catch (e) {}
  } else {
    const bc = $('#board-container');
    if (!bc.querySelector('.board-placeholder')) {
      bc.innerHTML = '<div class="board-placeholder">3D board loads here<br>(board module not attached yet)</div>';
    }
  }
  applyState(G.state);
};

function bindGame() {
  $('#dice-btn').addEventListener('click', doRoll);
  $('#game-leave').addEventListener('click', leaveGame);
  $('#go-home').addEventListener('click', () => {
    closeModal('#modal-gameover');
    leaveGame();
  });
}

/* ---------------- profile modal ---------------- */
let editingName = false;

function fillProfile(u) {
  u = u || {};
  const name = u.name || 'Player';
  $('#profile-avatar').textContent = avatarLetter(name);
  if (!editingName) $('#profile-name').textContent = name;
  $('#profile-earning').textContent = fmt(u.totalEarned !== undefined ? u.totalEarned : (u.earnings || 0));
  $('#profile-money').textContent = fmt(coinsOf(u));
  const s = u.stats || {};
  const played = Number(s.gamesPlayed !== undefined ? s.gamesPlayed : (u.gamesPlayed || 0)) || 0;
  const won = Number(s.gamesWon !== undefined ? s.gamesWon : (u.gamesWon || 0)) || 0;
  $('#st-played').textContent = fmt(played);
  $('#st-won').textContent = fmt(won);
  const rate = s.winRate !== undefined ? s.winRate : (played ? Math.round((won / played) * 100) : 0);
  $('#st-rate').textContent = rate + '%';
  $('#st-2p').textContent = fmt(s.wins2p !== undefined ? s.wins2p : (u.wins2p || 0));
  $('#st-4p').textContent = fmt(s.wins4p !== undefined ? s.wins4p : (u.wins4p || 0));
}

function openProfileModal() {
  editingName = false;
  fillProfile(store.user);
  openModal('#modal-profile');
  refreshMe().then(() => fillProfile(store.user));
}

function bindProfile() {
  $('#name-edit').addEventListener('click', async () => {
    const nameEl = $('#profile-name');
    if (!editingName) {
      editingName = true;
      const cur = (store.user && store.user.name) || '';
      const input = document.createElement('input');
      input.className = 'profile-name-input';
      input.id = 'profile-name';
      input.value = cur;
      input.maxLength = 30;
      nameEl.replaceWith(input);
      input.focus();
      input.select();
      toast('Edit your name, then tap the pencil again to save');
      return;
    }
    const input = $('#profile-name');
    const next = (input.value || '').trim();
    if (next.length < 2) { toast('Name must be at least 2 characters'); return; }
    $('#name-edit').disabled = true;
    try {
      const res = await Api.updateMe({ name: next });
      const user = res.user || res;
      if (user && (user.name || user.id || user._id)) store.user = user;
      else if (store.user) { store.user.name = next; store.user = store.user; }
      const span = document.createElement('span');
      span.className = 'profile-name';
      span.id = 'profile-name';
      input.replaceWith(span);
      editingName = false;
      fillProfile(store.user);
      renderHeader();
      toast('Name updated');
    } catch (e) {
      toast(e.message);
    }
    $('#name-edit').disabled = false;
  });

  $('#logout-btn').addEventListener('click', () => {
    try { Socket.disconnect(); } catch (e) {}
    socketWired = false;
    store.token = null;
    store.user = null;
    G.state = null;
    G.myColor = null;
    closeAllModals();
    location.hash = '#/auth';
  });
}

/* ---------------- coin modal ---------------- */
function openCoinModal() {
  $('#coin-balance').textContent = fmt(coinsOf(store.user));
  $('#daily-note').textContent = '';
  const btn = $('#daily-btn');
  btn.disabled = false;
  btn.textContent = 'Claim Daily Bonus';
  openModal('#modal-coin');
}

function bindCoin() {
  $('#daily-btn').addEventListener('click', async () => {
    const btn = $('#daily-btn');
    btn.disabled = true;
    btn.textContent = 'Claiming…';
    try {
      const res = await Api.dailyBonus();
      const amt = Number(res.amount !== undefined ? res.amount : (res.coins !== undefined ? res.coins : res.bonus)) || 0;
      $('#daily-note').textContent = amt ? 'Bonus claimed: +' + fmt(amt) + ' coins!' : 'Daily bonus claimed!';
      toast(amt ? 'Daily bonus: +' + fmt(amt) + ' coins' : 'Daily bonus claimed!');
      await refreshMe();
      $('#coin-balance').textContent = fmt(coinsOf(store.user));
    } catch (e) {
      $('#daily-note').textContent = e.message;
      toast(e.message);
    }
    btn.disabled = false;
    btn.textContent = 'Claim Daily Bonus';
  });
}

/* ---------------- dashboard ---------------- */
ENTER.dashboard = async () => {
  const grid = $('#stat-grid');
  grid.innerHTML = '<div class="loading">Loading stats…</div>';
  try {
    const res = await Api.stats();
    const s = res.stats || res;
    const played = Number(s.gamesPlayed) || 0;
    const won = Number(s.gamesWon) || 0;
    const rate = s.winRate !== undefined ? s.winRate : (played ? Math.round((won / played) * 100) : 0);
    const cards = [
      { v: fmt(played), l: 'Games Played' },
      { v: fmt(won), l: 'Games Won' },
      { v: rate + '%', l: 'Win Rate' },
      { v: fmt(s.coins !== undefined ? s.coins : coinsOf(store.user)), l: 'Coins' },
      { v: fmt(s.totalEarned || 0), l: 'Total Earned' },
      { v: fmt(s.wins2p || 0), l: '2P Wins' },
      { v: fmt(s.wins4p || 0), l: '4P Wins' }
    ];
    grid.innerHTML = '';
    cards.forEach((c, i) => {
      const el = document.createElement('div');
      el.className = 'stat-card' + (i === 4 ? ' wide' : '');
      el.innerHTML = '<div class="sv">' + esc(c.v) + '</div><div class="sl">' + esc(c.l) + '</div>';
      grid.appendChild(el);
    });
  } catch (e) {
    grid.innerHTML = '<div class="error-box">Could not load stats.<br>' + esc(e.message) + '</div>';
  }
};

function bindDashboard() {
  $('#dash-back').addEventListener('click', () => { location.hash = '#/home'; });
}

/* ---------------- global bindings ---------------- */
function bindGlobal() {
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-toast]');
    if (t) { toast(t.getAttribute('data-toast')); return; }
    const c = e.target.closest('[data-close]');
    if (c) {
      const ov = c.closest('.modal-overlay');
      if (ov) ov.classList.remove('open');
    }
  });
}

/* ---------------- boot ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  bindGlobal();
  bindAuth();
  bindHome();
  bindRooms();
  bindGame();
  bindProfile();
  bindCoin();
  bindDashboard();
  if (!location.hash) location.hash = '#/splash';
  navigate();
});

})();
