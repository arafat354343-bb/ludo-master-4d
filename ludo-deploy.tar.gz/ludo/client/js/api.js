/* Ludo Master 3D — REST API client.
 * Vanilla fetch wrapper. Attaches the stored JWT as a Bearer token.
 * On 401 the token is cleared and the user is sent back to #/auth. */
const Api = (() => {
  const TOKEN_KEY = 'ludo_token';

  function token() {
    return localStorage.getItem(TOKEN_KEY);
  }

  async function request(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    const t = token();
    if (t) headers['Authorization'] = 'Bearer ' + t;

    let res;
    try {
      res = await fetch(CONFIG.API_BASE + path, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined
      });
    } catch (e) {
      throw new Error('Network error — is the server running?');
    }

    if (res.status === 401) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem('ludo_user');
      if (location.hash !== '#/auth') location.hash = '#/auth';
      throw new Error('Session expired — please log in again.');
    }

    let data = null;
    try { data = await res.json(); } catch (e) { /* empty body */ }

    if (!res.ok) {
      throw new Error((data && (data.message || data.error)) || ('Request failed (' + res.status + ')'));
    }
    return data;
  }

  return {
    signup: (name, email, password) =>
      request('POST', '/api/auth/signup', { name, email, password }),
    login: (email, password) =>
      request('POST', '/api/auth/login', { email, password }),
    me: () =>
      request('GET', '/api/me'),
    updateMe: (patch) =>
      request('PUT', '/api/me', patch),
    stats: () =>
      request('GET', '/api/stats'),
    rooms: () =>
      request('GET', '/api/rooms'),
    dailyBonus: () =>
      request('POST', '/api/wallet/daily', {})
  };
})();
