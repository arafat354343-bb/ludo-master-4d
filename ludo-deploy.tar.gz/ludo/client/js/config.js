/* Ludo Master 3D — client configuration.
 * Served as a plain static site (no build step). Point these at the game server.
 * The Socket.IO client library is loaded from CDN in index.html; if it is
 * unavailable, js/socket.js falls back to a native WebSocket connection. */
const CONFIG = {
  API_BASE: 'http://localhost:3000',
  SOCKET_URL: 'http://localhost:3000',
  APP_NAME: 'Ludo Master 3D',
  TURN_SECONDS: 15
};
