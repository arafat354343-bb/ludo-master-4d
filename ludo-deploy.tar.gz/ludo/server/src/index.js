'use strict';

/**
 * Ludo game server — Express REST API + Socket.IO real-time play.
 *
 * VIRTUAL COINS ONLY. Coins are an in-game score with no cash value:
 * no add-money, no cash-out, no withdraw-to-money, no payment features.
 */

const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const bcrypt = require('bcryptjs');

const db = require('./db');
const { signToken, verifyToken, requireAuth } = require('./auth');
const GameManager = require('./game'); // fails fast if the shared engine is missing

const PORT = Number(process.env.PORT || 3000);
const ENTRIES = [40, 50, 60, 80, 300];
const winFor = (mode, entry) => Math.round(entry * (mode === '2p' ? 1.6 : 3.2));

const app = express();
app.use(express.json());
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Never expose password hashes: pick only the public fields.
const publicUser = (u) => (u ? { id: u.id, name: u.name, email: u.email, coins: u.coins } : null);

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.post('/api/auth/signup', async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'name is required' });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) {
    return res.status(400).json({ error: 'a valid email is required' });
  }
  if (!password || String(password).length < 6) {
    return res.status(400).json({ error: 'password must be at least 6 characters' });
  }
  try {
    const passwordHash = await bcrypt.hash(String(password), 10);
    const user = await db.createUser({ name: name.trim(), email: String(email).trim(), passwordHash });
    res.status(201).json({ token: signToken(user.id), user: publicUser(user) });
  } catch (e) {
    if (e.code === 'DUPLICATE_EMAIL') return res.status(409).json({ error: 'email already registered' });
    console.error('[api] signup failed:', e);
    res.status(500).json({ error: 'signup failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password are required' });
  try {
    const user = await db.findUserByEmail(String(email));
    if (!user) return res.status(401).json({ error: 'invalid credentials' });
    const ok = await bcrypt.compare(String(password), user.password_hash);
    if (!ok) return res.status(401).json({ error: 'invalid credentials' });
    res.json({ token: signToken(user.id), user: publicUser(user) });
  } catch (e) {
    console.error('[api] login failed:', e);
    res.status(500).json({ error: 'login failed' });
  }
});

app.get('/api/me', requireAuth, async (req, res) => {
  try {
    const user = await db.getUserById(req.userId);
    if (!user) return res.status(404).json({ error: 'user not found' });
    res.json(publicUser(user));
  } catch (e) {
    res.status(500).json({ error: 'failed to load profile' });
  }
});

app.put('/api/me', requireAuth, async (req, res) => {
  const { name } = req.body || {};
  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'name is required' });
  }
  try {
    const user = await db.updateUserName(req.userId, name.trim());
    res.json(publicUser(user));
  } catch (e) {
    if (e.code === 'USER_NOT_FOUND') return res.status(404).json({ error: 'user not found' });
    res.status(500).json({ error: 'update failed' });
  }
});

app.get('/api/stats', requireAuth, async (req, res) => {
  try {
    const stats = await db.getStats(req.userId);
    const user = await db.getUserById(req.userId);
    res.json({ ...stats, coins: user ? user.coins : 0 });
  } catch (e) {
    res.status(500).json({ error: 'stats failed' });
  }
});

app.get('/api/rooms', (req, res) => {
  res.json({
    twoPlayer: ENTRIES.map((entry) => ({ entry, win: winFor('2p', entry) })),
    fourPlayer: ENTRIES.map((entry) => ({ entry, win: winFor('4p', entry) })),
  });
});

app.post('/api/wallet/daily', requireAuth, async (req, res) => {
  try {
    res.json(await db.claimDailyBonus(req.userId));
  } catch (e) {
    res.status(500).json({ error: 'daily bonus failed' });
  }
});

/* ---------------- Socket.IO ---------------- */

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const games = new GameManager(io, db);

// Authenticate every socket via handshake.auth.token; drop unauthenticated ones.
io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) return next(new Error('unauthorized: missing token'));
    const { sub } = verifyToken(token);
    const user = await db.getUserById(sub);
    if (!user) return next(new Error('unauthorized: unknown user'));
    socket.user = { id: user.id, name: user.name, email: user.email };
    return next();
  } catch (e) {
    return next(new Error('unauthorized: invalid token'));
  }
});

io.on('connection', (socket) => {
  socket.on('queue:join', (p) => games.joinQueue(socket, p || {}));
  socket.on('queue:leave', () => games.leaveQueue(socket));
  socket.on('game:roll', () => games.handleRoll(socket));
  socket.on('game:move', (p) => games.handleMove(socket, p && p.token));
  socket.on('disconnect', () => games.handleDisconnect(socket));
});

/* ---------------- boot ---------------- */

function shutdown() {
  console.log('[server] shutting down…');
  server.close(() => {
    db.close().then(() => process.exit(0)).catch(() => process.exit(0));
  });
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

(async () => {
  try {
    await db.pgReady();
  } catch (e) {
    console.error('FATAL: DATABASE_URL is set but PostgreSQL is unreachable:', e.message);
    process.exit(1);
  }
  server.listen(PORT, () => console.log(`[server] listening on :${PORT}`));
})();
