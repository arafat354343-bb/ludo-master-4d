'use strict';

/**
 * Storage abstraction.
 *
 * - If process.env.DATABASE_URL is set → PostgreSQL via pg (migrations.sql).
 * - Otherwise → transparent in-memory fallback (Maps). Data is lost on restart.
 *
 * The rest of the codebase must not know which backend is active.
 *
 * VIRTUAL COINS ONLY. Coins have no cash value and cannot be withdrawn.
 */

const { randomUUID } = require('crypto');

const USE_PG = !!process.env.DATABASE_URL;
const STARTING_COINS = 5410;
const DAILY_BONUS_COINS = 500;

let pool = null;
if (USE_PG) {
  // Required lazily so the in-memory path never needs the pg package.
  const { Pool } = require('pg');
  pool = new Pool({ connectionString: process.env.DATABASE_URL });
  console.log('[db] PostgreSQL backend active');
} else {
  console.log('================================================================');
  console.log('[db] *** DEV in-memory DB *** — DATABASE_URL is not set.');
  console.log('[db] *** DEV in-memory DB *** — all data lives in process memory');
  console.log('[db] *** DEV in-memory DB *** — and is LOST when the server stops.');
  console.log('================================================================');
}

/** Fail fast at boot when DATABASE_URL is set but unreachable. */
async function pgReady() {
  if (!USE_PG) return;
  await pool.query('SELECT 1');
}

// ---------------- in-memory stores ----------------
const memUsers = new Map();     // id -> user row
const memEmailToId = new Map(); // lowercased email -> id
const memGames = [];            // game records

function dupEmailError() {
  const e = new Error('email already registered');
  e.code = 'DUPLICATE_EMAIL';
  return e;
}
function insufficientCoinsError() {
  const e = new Error('insufficient coins');
  e.code = 'INSUFFICIENT_COINS';
  return e;
}
function userNotFoundError() {
  const e = new Error('user not found');
  e.code = 'USER_NOT_FOUND';
  return e;
}

function toStats(row) {
  const played = row.games_played || 0;
  const won = row.games_won || 0;
  return {
    gamesPlayed: played,
    gamesWon: won,
    winRate: played > 0 ? Math.round((won / played) * 100) : 0,
    wins2p: row.wins_2p || 0,
    wins4p: row.wins_4p || 0,
    totalEarned: Number(row.total_earned || 0),
  };
}

async function createUser({ name, email, passwordHash }) {
  const cleanEmail = String(email).toLowerCase();
  if (USE_PG) {
    try {
      const r = await pool.query(
        `INSERT INTO users (id, name, email, password_hash, coins)
         VALUES ($1, $2, $3, $4, $5) RETURNING *`,
        [randomUUID(), name, cleanEmail, passwordHash, STARTING_COINS]
      );
      return r.rows[0];
    } catch (e) {
      if (e && e.code === '23505') throw dupEmailError();
      throw e;
    }
  }
  if (memEmailToId.has(cleanEmail)) throw dupEmailError();
  const now = new Date().toISOString();
  const u = {
    id: randomUUID(),
    name,
    email: cleanEmail,
    password_hash: passwordHash,
    coins: STARTING_COINS,
    games_played: 0,
    games_won: 0,
    wins_2p: 0,
    wins_4p: 0,
    total_earned: 0,
    last_daily_bonus: null, // 'YYYY-MM-DD'
    created_at: now,
  };
  memUsers.set(u.id, u);
  memEmailToId.set(cleanEmail, u.id);
  return { ...u };
}

async function findUserByEmail(email) {
  const cleanEmail = String(email).toLowerCase();
  if (USE_PG) {
    const r = await pool.query('SELECT * FROM users WHERE email = $1', [cleanEmail]);
    return r.rows[0] || null;
  }
  const id = memEmailToId.get(cleanEmail);
  return id ? { ...memUsers.get(id) } : null;
}

async function getUserById(id) {
  if (USE_PG) {
    const r = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    return r.rows[0] || null;
  }
  const u = memUsers.get(id);
  return u ? { ...u } : null;
}

async function updateUserName(id, name) {
  if (USE_PG) {
    const r = await pool.query('UPDATE users SET name = $2 WHERE id = $1 RETURNING *', [id, name]);
    if (r.rows.length === 0) throw userNotFoundError();
    return r.rows[0];
  }
  const u = memUsers.get(id);
  if (!u) throw userNotFoundError();
  u.name = name;
  return { ...u };
}

/**
 * Add delta to a user's balance (delta may be negative).
 * Rejects with INSUFFICIENT_COINS when the balance would go below 0.
 * Returns the new balance.
 */
async function addCoins(id, delta) {
  if (USE_PG) {
    const r = await pool.query(
      'UPDATE users SET coins = coins + $2 WHERE id = $1 AND coins + $2 >= 0 RETURNING coins',
      [id, delta]
    );
    if (r.rows.length === 0) {
      const exists = await pool.query('SELECT 1 FROM users WHERE id = $1', [id]);
      throw exists.rows.length === 0 ? userNotFoundError() : insufficientCoinsError();
    }
    return r.rows[0].coins;
  }
  const u = memUsers.get(id);
  if (!u) throw userNotFoundError();
  if (u.coins + delta < 0) throw insufficientCoinsError();
  u.coins += delta;
  return u.coins;
}

async function recordGame({ mode, entry, winnerId, playerIds }) {
  const rec = {
    id: randomUUID(),
    mode,
    entry,
    winner_id: winnerId || null,
    player_ids: playerIds || [],
    played_at: new Date().toISOString(),
  };
  if (USE_PG) {
    await pool.query(
      'INSERT INTO games (id, mode, entry, winner_id, player_ids) VALUES ($1, $2, $3, $4, $5)',
      [rec.id, rec.mode, rec.entry, rec.winner_id, JSON.stringify(rec.player_ids)]
    );
    return rec;
  }
  memGames.push(rec);
  return { ...rec };
}

async function incrementStats(userId, { played = 0, won = 0, mode = null, earned = 0 } = {}) {
  if (USE_PG) {
    await pool.query(
      `UPDATE users SET
         games_played = games_played + $2,
         games_won    = games_won + $3,
         wins_2p      = wins_2p + CASE WHEN $4 = '2p' THEN $3 ELSE 0 END,
         wins_4p      = wins_4p + CASE WHEN $4 = '4p' THEN $3 ELSE 0 END,
         total_earned = total_earned + $5
       WHERE id = $1`,
      [userId, played, won, mode, earned]
    );
    return;
  }
  const u = memUsers.get(userId);
  if (!u) throw userNotFoundError();
  u.games_played += played;
  u.games_won += won;
  if (mode === '2p') u.wins_2p += won;
  if (mode === '4p') u.wins_4p += won;
  u.total_earned += earned;
}

/**
 * Daily bonus: +500 coins, claimable once per calendar day.
 * Returns { granted: bool, coins: <balance after> }.
 */
async function claimDailyBonus(id) {
  if (USE_PG) {
    const r = await pool.query(
      `UPDATE users
         SET coins = coins + $2, last_daily_bonus = CURRENT_DATE
       WHERE id = $1
         AND (last_daily_bonus IS NULL OR last_daily_bonus < CURRENT_DATE)
       RETURNING coins`,
      [id, DAILY_BONUS_COINS]
    );
    if (r.rows.length > 0) return { granted: true, coins: r.rows[0].coins };
    const u = await pool.query('SELECT coins FROM users WHERE id = $1', [id]);
    if (u.rows.length === 0) throw userNotFoundError();
    return { granted: false, coins: u.rows[0].coins };
  }
  const u = memUsers.get(id);
  if (!u) throw userNotFoundError();
  const today = new Date().toISOString().slice(0, 10);
  if (u.last_daily_bonus === today) return { granted: false, coins: u.coins };
  u.last_daily_bonus = today;
  u.coins += DAILY_BONUS_COINS;
  return { granted: true, coins: u.coins };
}

async function getStats(userId) {
  const u = await getUserById(userId);
  if (!u) throw userNotFoundError();
  return toStats(u);
}

async function close() {
  if (pool) await pool.end();
}

module.exports = {
  createUser,
  findUserByEmail,
  getUserById,
  updateUserName,
  addCoins,
  recordGame,
  incrementStats,
  getStats,
  claimDailyBonus,
  pgReady,
  close,
  STARTING_COINS,
  DAILY_BONUS_COINS,
};
