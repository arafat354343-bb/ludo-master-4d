-- Ludo game server schema (PostgreSQL).
-- Run once against your database, e.g.:
--   psql "$DATABASE_URL" -f migrations.sql

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS users (
  id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name           TEXT        NOT NULL,
  email          TEXT        NOT NULL UNIQUE,
  password_hash  TEXT        NOT NULL,
  coins          INTEGER     NOT NULL DEFAULT 5410,
  games_played   INTEGER     NOT NULL DEFAULT 0,
  games_won      INTEGER     NOT NULL DEFAULT 0,
  wins_2p        INTEGER     NOT NULL DEFAULT 0,
  wins_4p        INTEGER     NOT NULL DEFAULT 0,
  total_earned   BIGINT      NOT NULL DEFAULT 0,
  last_daily_bonus DATE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS games (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  mode       TEXT        NOT NULL,              -- '2p' | '4p'
  entry      INTEGER     NOT NULL,              -- virtual-coin entry fee
  winner_id  UUID        REFERENCES users(id),  -- null when a bot won
  player_ids JSONB       NOT NULL DEFAULT '[]', -- human user ids
  played_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_games_winner_id ON games (winner_id);
CREATE INDEX IF NOT EXISTS idx_games_played_at ON games (played_at);
